<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quan tri</title>
    <style>
        *{
            margin: 0 auto;
            padding: 0;
        }
      .full{
          width: 100%;
          min-height: 1000px;
          background-color: wheat;
      }
    </style>
</head>
<body>
    <div class="full">
        <div class="sibar">
            
        </div>
        <div class="menu">
            
        </div>
    </div>
</body>
</html>