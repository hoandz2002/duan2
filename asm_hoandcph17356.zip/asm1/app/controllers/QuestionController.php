<?php 
namespace App\Controllers;
use App\Models\Question;
use App\Models\Quiz;

class QuestionController{
    public function show_question(){
        $id = $_GET['id'];     
        $questions = Question::where('quiz_id', '=',$id)->get();
        include 'we16303-php2/asm1/app/views/lam-bai/index.php';
    }

    //
    
    public function index(){
        $questions = Question::all();

        // include_once "./app/views/questions/index.php";
        return view('questions.index',[
            'questions'=>$questions
        ]);
    }
   
    public function addForm(){
        include_once "./app/views/questions/add-form.php";
    }

    public function editForm(){
        $id = $_GET['id'];
        $model = Question::where('id', '=', $id)->first();
        if(!$model){
            header('location: ' . BASE_URL . 'questions');
            die;
        }
        include_once './app/views/questions/edit-form.php';
    }

    public function saveAdd(){
        $model = new Question();
        $data = [
            'name' => $_POST['name'],
            'quiz_id' => $_POST['quiz_id']

        ];
        $model->insert($data);
        header('location: ' . BASE_URL . 'question');
        die;
    }

    public function saveEdit(){
        $id = $_GET['id'];
        $model = Question::where('id', '=', $id)->first();
        if(!$model){
            header('location: ' . BASE_URL . 'question');
            die;
        }

        $data = [
            'name' => $_POST['name']
        ];
        $model->update($data);
        header('location: ' . BASE_URL . 'question');
        die;
    }

    public function remove(){
        $id = $_GET['id'];
        Question::destroy($id);
        header('location: ' . BASE_URL . 'question');
        die;
    }
    public function list_questions(){
        $quiz_id=$_GET['quiz_id'];
        $questions=Question::where('quiz_id','=',$quiz_id)->get();
        include './app/views/questions/list-question.php';

    }
    public function chitiet_question(){
        $question_id=$_GET['question_id'];
        $questions=Question::where('question_id','=',$question_id)->get_checkid($question_id);
        include './app/views/questions/question-chitiet.php';
    }
}
?>