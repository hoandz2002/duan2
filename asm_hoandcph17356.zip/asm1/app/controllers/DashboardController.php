<?php
namespace App\Controllers;
class DashboardController{
    public function index(){
        include './app/views/dashboard/index.php';
    }
}
?>