<?php 
namespace App\Controllers;
use App\Models\Subject;
use App\Models\Quiz;
use App\Models\Question;
use App\Models\Answer;

class AnswerController{
    public function index(){
        $answer=Answer::all();

        // include_once "./app/views/tra-loi/index.php";
        return view('tra-loi.index',[
            'answer' => $answer
        ]);
    }
   
    public function addForm(){
        include_once "./app/views/tra-loi/add-form.php";
    }

    public function editForm(){
        $id = $_GET['id'];
        $model = Answer::where('id', '=', $id)->first();
        if(!$model){
            header('location: ' . BASE_URL . 'answer');
            die;
        }
        include_once './app/views/tra-loi/edit-form.php';
    }

    public function saveAdd(){
        $model = new Answer();
        $data = [
            'content' => $_POST['content'],
            'question_id' => $_POST['question_id'],
            'is_correct' => $_POST['is_correct']

        ];
        $model->insert($data);
        header('location: ' . BASE_URL . 'answer');
        die;
    }

    public function saveEdit(){
        $id = $_GET['id'];
        $model = Answer::where('id', '=', $id)->first();
        if(!$model){
            header('location: ' . BASE_URL . 'answer');
            die;
        }

        $data = [
            'content' => $_POST['content'],
            'question_id' => $_POST['question_id'],
            'is_correct' => $_POST['is_correct'],
            
        ];
        $model->update($data);
        header('location: ' . BASE_URL . 'answer');
        die;
    }

    public function remove(){
        $id = $_GET['id'];
        Answer::destroy($id);
        header('location: ' . BASE_URL . 'answer');
        die;
    }
    public function list_Answers()
    {
        $question_id=$_GET['question'];
        $answers=Answer::where('question_id','=',$question_id)->get();
        include './app/views/tra-loi/answer-list.php';
    }
    public function chitiet_answer()
    {
        $id=$_GET['answer_id'];
        $answer=Answer::where('id','=',$id)->get_checkid($id);
        include './app/views/tra-loi/answer-chitiet.php';
    }
    //
    public function answers($data, $quiz_id)
    {
        $right = 0;
        $wrong = 0;
        $no_answer = 0;
        
        $questions = Question::where('quiz_id', '=', $quiz_id)->get();
        foreach ($questions as $value) {
            if (isset($data[$value->id])) {
                if ($value->answer_id  == $data[$value->id]) {
                    $right++;
                } else if ($value->answer_id != $data[$value->id] && $data[$value->id] != NULL) {
                    $wrong++;
                }
            } else {
                $no_answer++;
            }
        }
        $array = array();
        $array['right'] = $right;
        $array['wrong'] = $wrong;
        $array['no_answer'] = $no_answer;
        return $array;
    }

    public function hienthikq()
    {
        $quiz_id = $_GET['quiz_id'];
        $subject_id = $_GET['id'];
        include './app/views/views_sv/dap-an.php';
    }
}
?>