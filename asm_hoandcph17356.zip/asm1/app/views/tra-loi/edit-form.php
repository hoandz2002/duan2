<form action="<?= BASE_URL . 'answer/luu-cap-nhat?id=' . $model->id ?>" method="POST">
    <div>
        <label for="">content</label>
        <input type="text" name="content" 
            value="<?= $model->content ?>">
    </div>
    <div>
        <label for="">question</label>
        <input type="text" name="question_id" 
            value="<?= $model->question_id?>">
    </div>
    <div>
        <label for="">is_correct</label>
        <input type="text" name="is_correct" 
            value="<?= $model->is_correct?>">
    </div>
    <div>
        <button type="submit">Lưu</button>
    </div>
</form>