<form action="<?= BASE_URL . 'answer/luu-tao-moi' ?>" method="post">
    <div>
        <label for="">content</label>
        <input type="text" name="content">
    </div>
    <div>
        <label for="">question</label>
        <input type="text" name="question_id">
    </div>
    <div>
        <label for="">is_correct</label>
        <input type="radio" name="is_correct" value="0" id=""> dung
        <input type="radio" name="is_correct" value="1" id=""> sai
    </div>
    <div>
        <button type="submit">Lưu</button>
    </div>
</form>