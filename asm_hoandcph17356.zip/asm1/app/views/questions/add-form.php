<form action="<?= BASE_URL . 'question/luu-tao-moi'?>" method="post">
    <div>
        <label for="">content</label>
        <input type="text" name="name">
    </div>
    <div>
        <label for="">quiz</label>
        <input type="text" name="quiz_id">
        
    </div>
    <div>
        <button type="submit">Lưu</button>
    </div>
</form>