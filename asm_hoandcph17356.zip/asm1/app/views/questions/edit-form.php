<form action="<?= BASE_URL . 'question/luu-cap-nhat?id=' . $model->id ?>" method="POST">
    <div>
        <label for="">content</label>
        <input type="text" name="name" 
            value="<?= $model->name ?>">
    </div>
    <div>
        <label for="">quiz</label>
        <input type="text" name="quiz_id" 
            value="<?= $model->quiz_id?>">
    </div>
    <div>
        <button type="submit">Lưu</button>
    </div>
</form>